<?php
// Some class named Entity in the global namespace
/**
 * @Annotation
 */
class Entity
{
}
