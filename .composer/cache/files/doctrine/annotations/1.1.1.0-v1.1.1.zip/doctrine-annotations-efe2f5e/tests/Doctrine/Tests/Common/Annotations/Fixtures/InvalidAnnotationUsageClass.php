<?php

namespace Doctrine\Tests\Common\Annotations\Fixtures;

/**
 * @NoAnnotation
 */
class InvalidAnnotationUsageClass
{
}