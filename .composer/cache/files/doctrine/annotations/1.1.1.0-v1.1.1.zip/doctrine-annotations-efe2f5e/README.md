# Doctrine Annotations

Docblock Annotations Parser library (extracted from Doctrine Common).

## Changelog

### v1.1

* Add Exception when ZendOptimizer+ or Opcache is configured to drop comments
